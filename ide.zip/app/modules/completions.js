/**
 * completions.js — Inline ghost-text completions (Copilot-style).
 * Registers a Monaco InlineCompletionsProvider that calls the backend.
 */
"use strict";
import { state } from "./state.js";
import { inferLang } from "./utils.js";

let _enabled = true;
let _authHeaders = () => ({});
let _backendUrl = "";

export function initCompletions(backendUrl, getAuthHeaders) {
  _backendUrl = backendUrl;
  _authHeaders = getAuthHeaders;
}

export function setCompletionsEnabled(v) { _enabled = !!v; }
export function getCompletionsEnabled()  { return _enabled; }

export function registerInlineCompletions() {
  if (!window.monaco) return;

  window.monaco.languages.registerInlineCompletionsProvider({ pattern: "**" }, {
    provideInlineCompletions: debounceProvider(async (model, position) => {
      if (!_enabled || !state.workspace || !_backendUrl) return { items: [] };

      const linePrefix = model.getValueInRange({
        startLineNumber: position.lineNumber,
        startColumn: 1,
        endLineNumber: position.lineNumber,
        endColumn: position.column,
      });

      // Don't complete on empty or very short lines
      if (!linePrefix.trim() || linePrefix.trim().length < 2) return { items: [] };

      // Get surrounding context (10 lines above cursor)
      const contextStart = Math.max(1, position.lineNumber - 10);
      const prefix = model.getValueInRange({
        startLineNumber: contextStart, startColumn: 1,
        endLineNumber: position.lineNumber, endColumn: position.column,
      });

      const suffix = model.getValueInRange({
        startLineNumber: position.lineNumber, startColumn: position.column,
        endLineNumber: Math.min(model.getLineCount(), position.lineNumber + 5), endColumn: 9999,
      });

      try {
        const baseUrl = _backendUrl.replace(/\/ask$/, "");
        const res = await fetch(baseUrl + "/api/complete", {
          method: "POST",
          headers: { "Content-Type": "application/json", ..._authHeaders() },
          body: JSON.stringify({
            prefix,
            suffix,
            language: inferLang(state.activeFile || ""),
            filePath: state.activeFile || "",
            maxTokens: 80,
          }),
          signal: AbortSignal.timeout(4000),
        });
        if (!res.ok) return { items: [] };
        const data = await res.json();
        const text = (data.completion || data.text || "").trimEnd();
        if (!text) return { items: [] };

        return {
          items: [{
            insertText: text,
            range: {
              startLineNumber: position.lineNumber,
              startColumn: position.column,
              endLineNumber: position.lineNumber,
              endColumn: position.column,
            },
          }],
        };
      } catch {
        return { items: [] };
      }
    }, 420),
    freeInlineCompletions() {},
  });
}

function debounceProvider(fn, ms) {
  let timer;
  return (...args) => new Promise(resolve => {
    clearTimeout(timer);
    timer = setTimeout(() => resolve(fn(...args)), ms);
  });
}
